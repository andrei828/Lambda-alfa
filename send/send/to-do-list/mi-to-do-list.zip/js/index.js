
// add notes.
$('input').keypress(function(e){
	if(e.keyCode === 13 || e.wich === 13){
		console.log('lodded');
		createNote();
	}
})

// mark notes as done .
$('ul').on('click', 'li' ,function(){
	$(this).toggleClass('done');
})

// deleting notes
$('ul').on('click', 'span' , function(e){
	$(this).parent().fadeOut(500, function(){
		$(this).remove();
	});
	e.stopPropagation();
});

function createNote(){
	let note = $('input').val();
	$('input').val('');
	console.log('create node logged');
	$('ul').append(
			`<li><span><i class="fa fa-minus-square" aria-hidden="true"></i></span> ${note}</li>`
			);
}


// show/hide the input.
$('.fa-pencil-square-o').click(function(){
	$('input').fadeToggle();
});